from setuptools import setup

setup(name='GBiStat',
      version='0.3',
      description='Statistics, Gaussian and Binomial distributions',
      packages=['GBiStat'],
      author = 'Rishikesh',
      author_email = 'rishusiva@gmail.com',
      zip_safe=False)